<?php
// hanya untuk include 2 file ini
require_once "DataAkses.php";
require_once "functions.php.php";

// file ini tidak digunakan tetapi jangan di hapus