<?php
/*
 * File Untuk Testing Data Array
 * */
$zs = array();

$temp = 100;
array_push($zs,$temp);

$temp = 100;
array_push($zs,$temp);

var_dump($zs);