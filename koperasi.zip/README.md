# koperasi
Pendeteksi Kelayakan Peminjaman Uang dengan Algoritma Fuzzy
